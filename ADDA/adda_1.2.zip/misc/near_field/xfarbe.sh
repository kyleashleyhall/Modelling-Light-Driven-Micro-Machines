~/atomsoft/ADDA/offxfarbe/xfarbe-2.6c/xfarbe $1 -xrm "xfarbe.autolev: off"  -xrm "xfarbe.x-annotation: on" -xrm "xfarbe.y-annotation: on"
